//
//  MTCSaccadeState.h
//  Experiment
//
//  Copyright (c) 2006-2021 All rights reserved.
//

#import "MTCStateSystem.h"

@interface MTCSaccadeState : LLState {

	NSTimeInterval expireTime;
}

@end
