//
//  VFIntertrialState.h
//  Experiment
//
//  Copyright (c) 2006-2021 All rights reserved.
//

#import "VFStateSystem.h"

@interface VFIntertrialState : LLState {

    NSTimeInterval    expireTime;
}

@end
