//
//  GRFEndtrialState.h
//  Experiment
//
//  Copyright (c) 2006-2021 All rights reserved.
//

#import "GRFStateSystem.h"

@interface GRFEndtrialState : LLState {

	NSTimeInterval	expireTime;
}

@end
