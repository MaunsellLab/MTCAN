//
//  MTCFixonState.h
//  Experiment
//
//  Copyright (c) 2006-2021 All rights reserved.
//

#import "MTCStateSystem.h"

@interface MTCFixonState : LLState {

	NSTimeInterval	expireTime;
}

@end
