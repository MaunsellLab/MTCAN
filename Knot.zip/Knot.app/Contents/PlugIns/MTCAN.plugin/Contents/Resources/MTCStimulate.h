//
//  MTCStimulate.h
//  Experiment
//
//  Copyright (c) 2006-2021 All rights reserved.
//

#import "MTCStateSystem.h"

@interface MTCStimulate : LLState {

	NSTimeInterval expireTime;
}

@end
