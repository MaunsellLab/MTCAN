function [stimToRTMS, postRTMS] = stimRTLimits()

  stimToRTMS = 350;               	% fixed stim on to RT time
  postRTMS = 200;                  	% end relative to RT
end
