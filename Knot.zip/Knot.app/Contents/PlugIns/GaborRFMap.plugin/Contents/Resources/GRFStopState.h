//
//  GRFStopState.h
//  Experiment
//
//  Copyright (c) 2006-2021 All rights reserved.
//

#import "GRFStateSystem.h"

@interface GRFStopState : LLState  {

}

@end
